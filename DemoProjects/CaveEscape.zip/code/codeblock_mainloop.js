function main(){
  open_window("Cave Escape", 432, 768);

  let game = new game_data();
  set_up_game(game);
  write_line("Initialized!");

  while(true)
  {
    process_events();
    clear_screen(rgba_color_from_double(1,1,1,1));
    update_game(game);
    draw_game(game);
    refresh_screen();
  }
}

﻿using SplashKitSDK;

public class ArrowGame
{
    public static void Main()
    {
        Window gameWindow = new Window("Arrow Key Game", 1000, 800);

        double playerX = 400;
        double playerY = 300;
        const int speed = 5;

        // loading background music
        SplashKit.LoadMusic("Background", "resources/sounds/background.mp3");
        SplashKit.PlayMusic("Background", -1);

        // lodaing  images
        Bitmap backgroundImage = SplashKit.LoadBitmap("BackgroundImage", "resources/images/background.jpg"); //background
        Bitmap playerImage = SplashKit.LoadBitmap("Player", "resources/images/player.png"); //player

        while (!gameWindow.CloseRequested)
        {
            SplashKit.ProcessEvents();

            SplashKit.DrawBitmap(backgroundImage, 0, 0);

            // player movements
            if (SplashKit.KeyDown(KeyCode.RightKey)) playerX += speed;
            if (SplashKit.KeyDown(KeyCode.LeftKey))  playerX -= speed;
            if (SplashKit.KeyDown(KeyCode.UpKey))    playerY -= speed;
            if (SplashKit.KeyDown(KeyCode.DownKey))  playerY += speed;

            
            DrawingOptions options = SplashKit.OptionScaleBmp(0.3f, 0.3f); //original size is 600x600, reducing that size
            SplashKit.DrawBitmap(playerImage, playerX, playerY, options);

            gameWindow.DrawText("Use keboard keys for movement", Color.Black, 10, 10);
            gameWindow.Refresh(60);
        }
    }
}
